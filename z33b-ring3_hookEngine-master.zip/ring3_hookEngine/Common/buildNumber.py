#coding:utf-8
print "我也很绝望"
import re
import os
import sys
import shutil

