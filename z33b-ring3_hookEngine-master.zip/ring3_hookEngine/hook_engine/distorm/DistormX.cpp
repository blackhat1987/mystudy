#include "stdafx.h"

extern "C"
{
#include "mnemonics.c"
#include "wstring.c"
#include "textdefs.c"
	//#include "../3rd/distorm/src/x86defs.c"
#include "prefix.c"
#include "operands.c"
#include "insts.c"
#include "instructions.c"
#include "distorm.c"
#include "decoder.c"
};

